# modDevTools

Rapid site development helper for MODX Revolution.

- Author: Kireev Vitaly <kireevvit@gmail.com>
- Further development: Thomas Jakobi <thomas.jakobi@partout.info>
- License: GNU GPLv2

## Contribute

If you would like to make a contribution, you can send a payment to kireevvit@gmail.com by PayPal

## Installation

MODX Package Management

## GitHub Repository

https://github.com/argnist/modDevTools
