Changelog for modDevTools
=========================

- 1.1.2
    - Option for enabling the context key in breadcrumb home

- 1.1.1
    - Show context key in breadcrumb home

- 1.1.0
    - Edit and Quick Edit chunks/templates from modDevTools CMP directly
    - Regenerate the chunks, templates and snippets usage link database in the CMP
    - Improved ExtJS display
    - Updated manager style
    - Search in CMP is case sensitive
    - Dropped Revo 2.2 compatibility

- 1.0.0
    - Resource list on Snippet update page
    - Resource list on Chunk update page
    - Elements tabs and action buttons in resource grids are displayed depending on user access permissions
    - Breadcrumbs are displayed in Resource Overview
    - Fix Ctrl-Z

- 0.9.8-rc2
    - Search and Replace panel for elements
    - BreadCrumbs panel for resource edit page
    - Fix log messages while install
- 0.9.5-rc1
    - Template list on chunk page
    - Name of the chunk is highlighted in template code for Ace
    - Save child element in focus instead of parent
- 0.9.0-beta
    - Initial release
