<?php
/**
 * Home controller class for modDevTools.
 *
 * @package moddevtools
 * @subpackage controller
 */

/**
 * Class modDevToolsHomeManagerController
 */
class modDevToolsHomeManagerController extends modExtraManagerController
{
    /** @var modDevTools $moddevtools */
    public $moddevtools;

    public function initialize()
    {
        $path = $this->modx->getOption('moddevtools.core_path', null, $this->modx->getOption('core_path') . 'components/moddevtools/');
        $this->moddevtools = $this->modx->getService('moddevtools', 'modDevTools', $path . '/model/moddevtools/', array(
            'core_path' => $path
        ));

        parent::initialize();
    }

    public function loadCustomCssJs()
    {
        parent::loadCustomCssJs();

        $this->addCss($this->moddevtools->config['cssUrl'] . 'mgr/main.css');
        $this->addJavascript($this->moddevtools->config['jsUrl'] . 'mgr/moddevtools.js');
        $this->addJavascript($this->moddevtools->config['jsUrl'] . 'mgr/misc/utils.js');
        $this->addJavascript($this->moddevtools->config['jsUrl'] . 'mgr/widgets/search.form.js');
        $this->addJavascript($this->moddevtools->config['jsUrl'] . 'mgr/widgets/regenerate.form.js');
        $this->addJavascript($this->moddevtools->config['jsUrl'] . 'mgr/widgets/home.panel.js');
        $this->addJavascript($this->moddevtools->config['jsUrl'] . 'mgr/sections/home.js');

        $this->addHtml('<script type="text/javascript">
            Ext.onReady(function() {
                modDevTools.config = ' . json_encode($this->moddevtools->config, JSON_PRETTY_PRINT) . ';
                MODx.load({xtype: "moddevtools-page-home"});
            });
        </script>');
    }

    public function getLanguageTopics()
    {
        return array('moddevtools:default');
    }

    public function process(array $scriptProperties = array())
    {
    }

    public function getPageTitle()
    {
        return $this->modx->lexicon('moddevtools');
    }

    public function getTemplateFile()
    {
        return $this->moddevtools->getOption('templatesPath') . 'home.tpl';
    }

    public function checkPermissions()
    {
        return $this->modx->hasPermission('view_chunk') && $this->modx->hasPermission('view_template');
    }
}
